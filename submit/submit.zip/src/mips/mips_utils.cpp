#include "mips_utils.h"

int ir_type_size(ValueType* ir_type) {
    if (auto int_type = dynamic_cast<IntType*>(ir_type)) {
        return 4;
    } else if (auto char_type = dynamic_cast<CharType*>(ir_type)) {
        return 1;
    } else if (auto array_type = dynamic_cast<ArrayType*>(ir_type)) {
        return array_type->size * ir_type_size(array_type->element_type);
    } else if (auto pointer_type = dynamic_cast<PointerType*>(ir_type)) {
        return 4;
    } else {
        std::cout << "MIPS Alloca : Invalid Type!" << std::endl;
        return 0;
    }
}

bool is_const_value(Value* value) {
    if (auto intconst_ptr = dynamic_cast<IntConst*>(value)) {
        return true;
    } else if (auto charconst_ptr = dynamic_cast<CharConst*>(value)) {
        return true;
    } else {
        return false;
    }
}

int get_const_value(Value* value) {
    if (auto intconst_ptr = dynamic_cast<IntConst*>(value)) {
        return intconst_ptr->value;
    } else if (auto charconst_ptr = dynamic_cast<CharConst*>(value)) {
        return charconst_ptr->value;
    } else {
        std::cout << "Get Const Value : Invalid Value!" << std::endl;
        return -1;
    }
}